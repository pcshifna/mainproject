import React from "react";
import style from "./Swipercomponent.module.css";

const swiperComponent = (props) => {
  return (
    // <div className={style.newparent}>
    //   <div className={style.full}>
    //     <div className={style.swiperParent}>
    //       <img src={roundGrid} alt="" />
    //     </div>
    //     <div className={style.square}></div>
    //   </div>
    // </div>
    <div className={style.full}>
      <div className={style.swiperParent}>
        <img src={props?.data?.image} />
      </div>
      <p>{props?.data?.title}</p>
      <div className={style.square}></div>
    </div>
  );
};

export default swiperComponent;
